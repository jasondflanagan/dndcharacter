import React, {Component} from 'react';

class CharacterBuilder extends Component{

    render(){
        return(
            <h1>Character Builder</h1>
        )
    }

}

export default CharacterBuilder