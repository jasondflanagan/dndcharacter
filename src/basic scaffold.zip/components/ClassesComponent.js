import React, { Component } from 'react';





class CharacterClasses extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }
    render() {
        return (
            <React.Fragment>
                <h1>Classes</h1>
            </React.Fragment>
        );
    }
};

export default CharacterClasses;