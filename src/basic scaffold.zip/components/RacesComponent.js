import React, { Component } from 'react';
//import "@fontsource/medievalsharp";
import { RACE } from './RaceComponent';




class Races extends Component {
    constructor(props) {
        super(props);
        this.state = {
            race: RACE 
        };
    }
    render() {
        return (
            <React.Fragment>
                <h1>Races</h1>
            </React.Fragment>
        );
    }
};

export default Races;