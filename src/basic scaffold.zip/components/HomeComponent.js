import React, { Component } from 'react';

//import "@fontsource/medievalsharp";


class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }
    render() {
        return (
          <React.Fragment>
            <h1>home</h1>
          </React.Fragment>
        );
      }
    };
    export default Home;